<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>eLibrary - Your Digital Knowledge Hub</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .carousel-item img {
            height: 300px;
            object-fit: cover;
            border-radius: 10px;
        }
        .carousel-caption {
            background: rgba(0, 0, 0, 0.7);
            border-radius: 10px;
            padding: 15px;
        }
        .carousel-caption h3 {
            font-size: 1.5rem;
            margin-bottom: 10px;
        }
        .carousel-caption p {
            font-size: 1rem;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="#">eLibrary</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    @auth
                        <li class="nav-item">
                            <span class="nav-link">Welcome, {{ Auth::user()->name }}</span>
                        </li>
                        @if (Auth::user()->role_id === 1 || Auth::user()->role_id === 2)
                            <li class="nav-item">
                                <a class="nav-link" href="{{ route('admin.classes.index') }}">Manage Classes</a>
                            </li>
                        @endif
                        <li class="nav-item">
                            <form action="{{ route('logout') }}" method="POST">
                                @csrf
                                <button type="submit" class="nav-link btn btn-link">Logout</button>
                            </form>
                        </li>
                    @else
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('login') }}">Login</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('register') }}">Register</a>
                        </li>
                    @endauth
                </ul>
            </div>
        </div>
    </nav>

    <div class="container my-5">
        <div class="text-center">
            <h1>Welcome to Upperlink eLibrary</h1>
            <p class="lead">Explore a world of knowledge with our digital library platform.</p>
        </div>

        <div class="row mt-4">
            <div class="col-md-8 offset-md-2">
                <h2>Why Choose Our eLibrary?</h2>
                <div id="elibraryCarousel" class="carousel slide" data-bs-ride="carousel">
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <img src="{{ asset('img/imgc3.jpg')  }}" class="d-block w-100" alt="Extensive Collection">
                            <div class="carousel-caption d-block">
                                <h3>Extensive Collection</h3>
                                <p>Thousands of books, journals, and resources across all disciplines.</p>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <img src="{{ asset('img/imgc1.jpg')  }}" class="d-block w-100" alt="Powerful Search">
                            <div class="carousel-caption d-block">
                                <h3>Powerful Search</h3>
                                <p>Easily find books by title, author, or category.</p>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <img src="{{ asset('img/imgc2.jpg')  }}" class="d-block w-100" alt="Seamless Access">
                            <div class="carousel-caption d-block">
                                <h3>Seamless Access</h3>
                                <p>Read online or download for offline use.</p>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <img src="{{ asset('img/imgc4.jpg')  }}" class="d-block w-100" alt="Personalized Accounts">
                            <div class="carousel-caption d-block">
                                <h3>Personalized Accounts</h3>
                                <p>Track borrowing, reservations, and reading history.</p>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <img src="https://source.unsplash.com/800x300/?admin,dashboard" class="d-block w-100" alt="Admin Management">
                            <div class="carousel-caption d-block">
                                <h3>Admin Management</h3>
                                <p>Tools for admins to manage books, classes, and users.</p>
                            </div>
                        </div>
                    </div>
                    <button class="carousel-control-prev" type="button" data-bs-target="#elibraryCarousel" data-bs-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Previous</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#elibraryCarousel" data-bs-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Next</span>
                    </button>
                </div>
                <div class="mt-4 text-center">
                    <a href="{{ route('resources.index') }}" class="btn btn-primary">Browse Books</a>
                    @if (Auth::check() && (Auth::user()->role_id === 1 || Auth::user()->role_id === 2))
                        <a href="{{ route('admin.classes.index') }}" class="btn btn-secondary">Manage Classes</a>
                    @endif
                </div>
            </div>
        </div>
    </div>

    <footer class="bg-light py-3 mt-5">
        <div class="container text-center">
            <p>&copy; {{ date('Y') }} eLibrary. All rights reserved.</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>eLibrary - Your Digital Knowledge Hub</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="#">eLibrary</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    @auth
                        <li class="nav-item">
                            <span class="nav-link">Welcome, {{ Auth::user()->name }}</span>
                        </li>
                        @if (Auth::user()->role_id === 1 || Auth::user()->role_id === 2)
                            <li class="nav-item">
                                <a class="nav-link" href="{{ route('admin.classes.index') }}">Manage Classes</a>
                            </li>
                        @endif
                        <li class="nav-item">
                            <form action="{{ route('logout') }}" method="POST">
                                @csrf
                                <button type="submit" class="nav-link btn btn-link">Logout</button>
                            </form>
                        </li>
                    @else
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('login') }}">Login</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('register') }}">Register</a>
                        </li>
                    @endauth
                </ul>
            </div>
        </div>
    </nav>

    <div class="container my-5">
        <div class="text-center">
            <h1>Welcome to eLibrary</h1>
            <p class="lead">Explore a world of knowledge with our digital library platform.</p>
        </div>

        <div class="row mt-4">
            <div class="col-md-6 offset-md-3">
                <h2>Why Choose Our eLibrary?</h2>
                <ul class="list-group">
                    <li class="list-group-item">📚 <strong>Extensive Collection</strong>: Thousands of books, journals, and resources across all disciplines.</li>
                    <li class="list-group-item">🔍 <strong>Powerful Search</strong>: Easily find books by title, author, or category.</li>
                    <li class="list-group-item">📖 <strong>Seamless Access</strong>: Read online or download for offline use.</li>
                    <li class="list-group-item">🔒 <strong>Personalized Accounts</strong>: Track borrowing, reservations, and reading history.</li>
                    <li class="list-group-item">⚙️ <strong>Admin Management</strong>: Tools for admins to manage books, classes, and users.</li>
                </ul>
                <div class="mt-4">
                    <a href="{{ route('resources.index') }}" class="btn btn-primary">Browse Books</a>
                    @if (Auth::check() && (Auth::user()->role_id === 1 || Auth::user()->role_id === 2))
                        <a href="{{ route('admin.classes.index') }}" class="btn btn-secondary">Manage Classes</a>
                    @endif
                </div>
            </div>
        </div>
    </div>

    <footer class="bg-light py-3 mt-5">
        <div class="container text-center">
            <p>&copy; {{ date('Y') }} eLibrary. All rights reserved.</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> -->
