@extends('layouts.admin')

@section('content')
<div class="container">
    <h1 class="mb-4">My Library</h1>

    <!-- Featured Section -->
    @if($featured->count())
    <div class="mb-5">
        <h3>🌟 Featured Resources</h3>
        <div class="row">
            @foreach($featured as $resource)
            <div class="col-md-4 mb-4">
                <div class="card border-primary shadow-sm h-100">
                    @if($resource->file && in_array(pathinfo($resource->file, PATHINFO_EXTENSION), ['jpg', 'jpeg', 'png', 'gif']))
                        <img src="{{ asset('storage/' . $resource->file) }}" alt="{{ $resource->title }}" class="card-img-top" style="width: 100%; height: 150px; object-fit: cover;">
                    @endif
                    <div class="card-body">
                        <h5 class="card-title">{{ $resource->title }}</h5>
                        <p class="card-text">{{ Str::limit($resource->description, 80) }}</p>
                        <span class="badge bg-warning text-dark">{{ ucfirst(optional($resource->resourceType)->name ?? 'N/A') }}</span>
                        
                        <div class="mt-3">
                            @if($resource->view_online)
                                <a href="{{ asset('storage/' . $resource->file_path) }}" target="_blank" class="btn btn-sm btn-outline-primary">Open</a>
                            @endif
                           
                            @if($resource->downloadable && $resource->file_path)
                                <a href="{{ asset('storage/' . $resource->file_path) }}" download class="btn btn-sm btn-outline-success">Download</a>
                            @endif
                            <a href="{{ route('student.resource.show', $resource->id) }}" class="btn btn-sm btn-outline-info">View Details</a>
                        </div>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
    @endif

    <!-- Search and Filter Form -->
    <form method="GET" action="{{ route('student.dashboard') }}" class="row mb-4">
        @csrf
        <div class="col-md-6">
            <input type="text" name="search" value="{{ request('search') }}" class="form-control" placeholder="Search resources...">
        </div>
        <div class="col-md-4">
            <select name="category_id" class="form-control">
                <option value="">All Categories</option>
                @foreach($categories as $category)
                    <option value="{{ $category->id }}" @selected(request('category_id') == $category->id)>{{ $category->name }}</option>
                @endforeach
            </select>
        </div>
        <div class="col-md-2">
            <button type="submit" class="btn btn-primary w-100">Filter</button>
        </div>
    </form>

    <!-- Resources Grid -->
    <div class="row">
        @forelse($resources as $resourceAccess)
        <div class="col-md-4 mb-4">
            <div class="card h-100 shadow-sm">
                @if($resourceAccess->resource->file_path && in_array(pathinfo($resourceAccess->resource->file_path, PATHINFO_EXTENSION), ['jpg', 'jpeg', 'png', 'gif']))
                    <img src="{{ asset('storage/' . $resourceAccess->resource->file_path) }}" alt="{{ $resourceAccess->resource->file_path }}" class="card-img-top" style="width: 100%; height: 150px; object-fit: cover;">
                @endif
                <div class="card-body">
                    <h5 class="card-title">{{ $resourceAccess->resource->title }}</h5>
                    <p class="card-text">{{ Str::limit($resourceAccess->resource->description, 100) }}</p>
                    <span class="badge bg-info text-dark">{{ ucfirst(optional($resourceAccess->resource->resourceType)->name ?? 'N/A') }}</span>
                    <div class="mt-3">
                        @if($resourceAccess->resource->view_online)
                            <a href="{{ asset('storage/' . $resourceAccess->resource->file_path) }}" target="_blank" class="btn btn-sm btn-outline-primary">Open</a>
                        @endif
                        @if($resourceAccess->resource->downloadable && $resourceAccess->resource->file_path)
                            <a href="{{ asset('storage/' . $resourceAccess->resource->file_path) }}" download class="btn btn-sm btn-outline-success">Download</a>
                        @endif
                        <a href="{{ route('student.resource.show', $resourceAccess->resource->id) }}" class="btn btn-sm btn-outline-info">View Details</a>
                    </div>
                </div>
            </div>
        </div>
        @empty
        <p>No resources found.</p>
        @endforelse
    </div>

    <div class="mt-4">
        {{ $resources->withQueryString()->links() }}
    </div>
</div>
@endsection