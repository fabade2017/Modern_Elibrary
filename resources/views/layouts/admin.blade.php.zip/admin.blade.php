
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ config('app.name', 'Institution Connect') }}</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .navbar-brand {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .site-logo {
            width: 40px;
            height: 40px;
            object-fit: contain;
            border-radius: 4px;
        }
        .site-name {
            font-size: 1.5rem;
            font-weight: 600;
            color: #fff;
        }
        .navbar {
            background: linear-gradient(135deg, #061225ff, #93c5fd);
        }
        .nav-link, .dropdown-item {
            color: #fff !important;
        }
        .nav-link:hover, .dropdown-item:hover {
            background-color: rgba(255, 255, 255, 0.2);
        }
        .modal-content {
            border-radius: 8px;
            border: none;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .modal-header {
            background: linear-gradient(135deg, #031229ff, #041324ff);
            color: #fff;
            border-top-left-radius: 8px;
            border-top-right-radius: 8px;
        }
        .modal-body {
            background: #f9fafb;
        }
        .logo-preview {
            max-width: 100px;
            max-height: 100px;
            object-fit: contain;
            border-radius: 4px;
        }
    </style>
    @yield('styles')
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="{{ route('admin.dashboard') }}">
                @php
                    $logoPath = DB::table('settings')->where('key', 'site_logo')->value('value') ?? 'logos/default.png';
                @endphp
                <img src="{{ asset('storage/' . $logoPath) }}?t={{ time() }}" alt="Site Logo" class="site-logo">
                <span class="site-name">{{ config('app.name', 'Institution Connect') }}</span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('admin.dashboard') }}">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('data-handler') }}">Data Handler</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="settingsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Settings
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="settingsDropdown">
                            <li>
  <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#logoUploadModal" style="color: black !important;">
    Change Logo
  </a>
</li>                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Logo Upload Modal -->
    <div class="modal fade" id="logoUploadModal" tabindex="-1" aria-labelledby="logoUploadModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="logoUploadModalLabel">Update Site Logo</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="logoUploadForm" enctype="multipart/form-data">
                        @csrf
                        <div class="mb-3">
                            <label for="logo" class="form-label">Choose Logo (PNG/JPG, max 2MB)</label>
                            <input type="file" class="form-control" id="logo" name="logo" accept="image/png,image/jpeg" required>
                        </div>
                        <img src="{{ asset('storage/' . $logoPath) }}?t={{ time() }}" alt="Current Logo" class="logo-preview mb-3">
                        <button type="submit" class="btn btn-primary">Upload Logo</button>
                    </form>
                    <div id="logoUploadResult" class="mt-3"></div>
                </div>
            </div>
        </div>
    </div>
  @include('layouts.admin_navbar')
    <main class="py-4">
        @yield('content')
    </main>
@yield('script');
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#logoUploadForm').submit(function(e) {
                e.preventDefault();
                const formData = new FormData(this);
                $.ajax({
                    url: '{{ route("settings.update-logo") }}',
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        console.log('Upload response:', response);
                        $('#logoUploadResult').html(`<div class="alert alert-success">${response.message}</div>`);
                        const newLogoUrl = response.logo_url + '?t=' + new Date().getTime();
                        $('.site-logo').attr('src', newLogoUrl).on('error', function() {
                            console.error('Failed to load logo:', newLogoUrl);
                            $(this).attr('src', '{{ asset('storage/logos/default.png') }}');
                        });
                        $('.logo-preview').attr('src', newLogoUrl).on('error', function() {
                            console.error('Failed to load preview:', newLogoUrl);
                            $(this).attr('src', '{{ asset('storage/logos/default.png') }}');
                        });
                        setTimeout(() => $('#logoUploadModal').modal('hide'), 1500);
                    },
                    error: function(err) {
                        console.error('Upload error:', err);
                        $('#logoUploadResult').html(`<div class="alert alert-danger">Error: ${err.responseJSON?.error || 'Failed to upload logo'}</div>`);
                    }
                });
            });
        });
    </script>
    @yield('scripts')
    @if(session('error'))
<script>
    document.addEventListener("DOMContentLoaded", function () {
        alert("{{ session('error') }}");
    });
</script>
@endif

    @if(session('error'))
<!-- Toast container -->
<div id="errorToast" 
     class="toast align-items-center text-bg-danger border-0 position-fixed bottom-0 end-0 m-3"
     role="alert" aria-live="assertive" aria-atomic="true">
  <div class="d-flex">
    <div class="toast-body">
      {{ session('error') }}
    </div>
    <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
  </div>
</div>

<!-- Bootstrap JS (must be included once in layout) -->

<script>
document.addEventListener("DOMContentLoaded", function () {
    const toastEl = document.getElementById("errorToast");
    if (toastEl) {
        const toast = new bootstrap.Toast(toastEl, { delay: 5000 });
        toast.show();
    }
});
</script>
@endif

</body>
</html>
