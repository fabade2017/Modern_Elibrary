
@extends('layouts.admin')

@section('content')
<div class="container">
    <h2>API Data Mapping</h2>

    {{-- Form to paste API URL --}}
    <form action="{{ route('data_mapper.fetch_api') }}" method="POST" class="mb-4">
        @csrf
        <div class="form-group">
            <label for="api_url">API URL</label>
            <input type="text" name="api_url" id="api_url" class="form-control" placeholder="Paste API URL here" required>
        </div>
        <button type="submit" class="btn btn-primary mt-2">Fetch & Create Table</button>
    </form>

    {{-- Mapping form --}}
    <form action="{{ route('data_mapper.save_mapping') }}" method="POST" id="mappingForm">
        @csrf
        <div class="row">
            <div class="col-md-6">
                <label for="api_table">Select API Table</label>
                <select name="api_table" id="api_table" class="form-control">
                    <option value="">-- Select --</option>
                    @foreach($tables as $table)
                        <option value="{{ $table }}">{{ $table }}</option>
                    @endforeach
                </select>
            </div>
            <div class="col-md-6">
                <label for="target_table">Select Target Table</label>
                <select name="target_table" id="target_table" class="form-control">
                    <option value="">-- Select --</option>
                    @foreach($tables as $table)
                        <option value="{{ $table }}">{{ $table }}</option>
                    @endforeach
                </select>
            </div>
        </div>

        <hr>

        <h4>Field Mapping</h4>
        <div id="mapping-area" class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>API Column</th>
                        <th>Target Column</th>
                    </tr>
                </thead>
                <tbody id="mapping-body"></tbody>
            </table>
        </div>

        <button type="button" id="addMapping" class="btn btn-secondary mt-2">Add Mapping</button>
        <button type="submit" class="btn btn-success mt-2">Save Mapping</button>
    </form>

    <form action="{{ route('data_mapper.delete_data') }}" method="POST" class="mt-4">
        @csrf
        <div class="row">
            <div class="col-md-6">
                <label for="delete_api_table">API Table</label>
                <select name="api_table" class="form-control">
                    @foreach($tables as $table)
                        <option value="{{ $table }}">{{ $table }}</option>
                    @endforeach
                </select>
            </div>
            <div class="col-md-6">
                <label for="delete_target_table">Target Table</label>
                <select name="target_table" class="form-control">
                    @foreach($tables as $table)
                        <option value="{{ $table }}">{{ $table }}</option>
                    @endforeach
                </select>
            </div>
        </div>
        <button type="submit" class="btn btn-danger mt-3">Delete Data</button>
    </form>
</div>
@endsection

@section('scripts')
<script>
document.addEventListener("DOMContentLoaded", function () {
    const apiTableSelect = document.getElementById("api_table");
    const targetTableSelect = document.getElementById("target_table");
    const mappingBody = document.getElementById("mapping-body");
    const addMappingBtn = document.getElementById("addMapping");

    function loadColumns() {
        const apiTable = apiTableSelect.value;
        const targetTable = targetTableSelect.value;

        if (apiTable && targetTable) {
            fetch(`/admin/data_mapper/get-columns?api_table=${encodeURIComponent(apiTable)}&target_table=${encodeURIComponent(targetTable)}`)
                .then(response => {
                    if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
                    return response.json();
                })
                .then(data => {
                    console.log('Columns fetched:', data);
                    mappingBody.innerHTML = "";
                    if (data.api_columns && data.target_columns) {
                        data.api_columns.forEach(apiCol => {
                            const row = `
                                <tr>
                                    <td>${apiCol}</td>
                                    <td>
                                        <select name="mappings[${apiCol}]" class="form-select">
                                            <option value="">-- Select Target Column --</option>
                                            ${data.target_columns.map(tc => `<option value="${tc}">${tc}</option>`).join('')}
                                        </select>
                                    </td>
                                </tr>
                            `;
                            mappingBody.innerHTML += row;
                        });
                    } else {
                        mappingBody.innerHTML = '<tr><td colspan="2">No columns available</td></tr>';
                    }
                })
                .catch(error => {
                    console.error('Error fetching columns:', error);
                    mappingBody.innerHTML = '<tr><td colspan="2">Error loading columns</td></tr>';
                });
        } else {
            mappingBody.innerHTML = '<tr><td colspan="2">Please select both API and Target tables</td></tr>';
        }
    }

    function fetchColumns(table, fieldName) {
        if (!table) return;

        fetch(`/admin/data_mapper/get-columns?table=${encodeURIComponent(table)}`)
            .then(response => {
                if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
                return response.json();
            })
            .then(data => {
                console.log(`Columns for ${table}:`, data);
                let options = `<option value="">-- Select Column --</option>`;
                data.forEach(col => {
                    options += `<option value="${col}">${col}</option>`;
                });
                window[fieldName + 'Options'] = options;
            })
            .catch(error => {
                console.error(`Error fetching columns for ${table}:`, error);
            });
    }

    apiTableSelect.addEventListener('change', function () {
        fetchColumns(this.value, 'apiCol');
        loadColumns();
    });

    targetTableSelect.addEventListener('change', function () {
        fetchColumns(this.value, 'targetCol');
        loadColumns();
    });

    addMappingBtn.addEventListener('click', function () {
        const div = document.createElement('tr');
        div.innerHTML = `
            <td>
                <select name="mapping[api][]" class="form-control apiCol">
                    ${window.apiColOptions || '<option>-- Load API Columns --</option>'}
                </select>
            </td>
            <td>
                <select name="mapping[target][]" class="form-control targetCol">
                    ${window.targetColOptions || '<option>-- Load Target Columns --</option>'}
                </select>
            </td>
        `;
        mappingBody.appendChild(div);
    });

    // Initial load
    loadColumns();
});
</script>
@endsection
