@extends('layouts.admin')

@section('content')
<div class="container">
    <h1 class="mb-4">Everyone in the eLibrary {{$subdomain}}</h1>
@auth
@if(Auth::user()->role_id === 1)
    <a href="{{ route('admin.users.create') }}" class="btn btn-primary mb-3">+ Add User</a>
  
    <a href="{{ route('school_admin_mappers.download', ['search' => request('search')]) }}" 
   class="btn btn-success mb-3"  style="float: right;">Download CSV</a>
  @endif
  @endauth
<form method="GET" action="{{ route('users.index') }}" class="mb-3">
    <div class="input-group">
        <input type="text" name="search" value="{{ request('search') }}" class="form-control" placeholder="Search by school, email...">
        <button class="btn btn-primary" type="submit">Search</button>
    </div>
</form>

    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Role</th>
                <th>Class</th>
                
                <th>Department</th>

                 <th>Category</th>
                <th>Arm</th>
                <th>Group</th>
                <th>Active</th>
      
@if(Auth::user()->role_id === 1)      <th>Actions</th> @endif 

            </tr>
        </thead>
        <tbody>
        @forelse($users as $user)
            <tr>
                <td class="user-row" data-id="{{$user->id}}">{{ $user->name }}</td>
                <td>{{ $user->email }}</td>
                <td> {{ $user->role ?? '—' }}</td>
             
                <td>{{ $user->classes->name ?? '—' }}</td>
                     <td>{{ $user->department->name ?? '—' }}</td>
                          <td>{{ $user->category->name ?? '—' }}</td>
                            <td>{{ $user->arm->name ?? '—' }}</td>
                              <td><ul> @foreach($user->groups as $group)
            <li>{{ $group->name }}</li>
        @endforeach</ul></td>
                 
                <td>
                 <form action="{{ route('users.toggle-active',$user->id) }}" method="POST">
                            @csrf @method('PATCH')
                            <button type="submit" class="btn btn-sm {{ $user->active ? 'btn-success':'btn-secondary' }}">
                                {{ $user->active ? 'Active':'Inactive' }}
                            </button>
                        </form>
</td>
            
@if(Auth::user()->role_id === 1)   <td>
                    <a href="{{ route('admin.users.edit', $user) }}" class="btn btn-sm btn-warning">Edit</a>
                    <form action="{{ route('admin.users.destroy', $user) }}" method="POST" class="d-inline">
                        @csrf @method('DELETE')
                        <button class="btn btn-sm btn-danger" onclick="return confirm('Delete this user?')">Delete</button>
                    </form>
                </td>
                @endif
              
            </tr>
        @empty
            <tr><td colspan="7">No users found.</td></tr>
        @endforelse
        </tbody>
    </table>
     {{ $users->links() }}
</div>  
<!-- Tooltip container -->
<div id="user-tooltip" 
     class="card shadow-sm p-2 position-absolute d-none" 
     style="width: 250px; z-index: 1000;">
    <div id="tooltip-content">Loading...</div>
</div>
<!-- <div class="modal fade" id="userInfoModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">User Info</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body" id="userInfoContent">
        Loading...
      </div>
    </div>
  </div>
</div> -->

@endsection
@section('scripts')
<script>
 /*   $(document).ready(function() {
    $('.user-row').hover(function() {
        let userId = $(this).data('id');

        $.get('/user/details/' + userId, function(data) {
            let content = `
                <p><strong>Surname:</strong> ${data.surname ?? 'N/A'}</p>
                <p><strong>Firstname:</strong> ${data.firstname ?? 'N/A'}</p>
                <p><strong>Othername:</strong> ${data.othername ?? 'N/A'}</p>
                 <p><strong>Admission NO:</strong> ${data.admission_number ?? 'N/A'}</p>
                <p><strong>Arm:</strong> ${data.arm ?? 'N/A'}</p>
                <p><strong>Category:</strong> ${data.category ?? 'N/A'}</p>
            `;
            $('#userInfoContent').html(content);

            // Show modal
            $('#userInfoModal').modal('show');
        });
    }, function() {
        // Optional: hide modal when mouse leaves row
        // $('#userInfoModal').modal('hide');
    });
});
 
*/
    </script>
    <script>
document.addEventListener("DOMContentLoaded", function () {
    const tooltip = document.getElementById("user-tooltip");
    const tooltipContent = document.getElementById("tooltip-content");

    document.querySelectorAll(".user-row").forEach(row => {
        row.addEventListener("mouseenter", function (e) {
        let userId = $(this).data('id');
              //   let userId = this.dataset.userId;

            // Fetch additional info from another table via AJAX
            fetch(`/user/details/${userId}`)
                .then(res => res.json())
                .then(data => {
                   tooltipContent.innerHTML = `
    <div class="card shadow-lg border-0" style="width: 18rem;">
        <div class="card-header bg-primary text-white text-center">
            <h5 class="mb-0">${userId}</h5>
        </div>
        <div class="card-body">
            <p class="mb-1"><strong>Surname:</strong> ${data.surname ?? 'N/A'}</p>
            <p class="mb-1"><strong>Firstname:</strong> ${data.firstname ?? 'N/A'}</p>
            <p class="mb-1"><strong>Othername:</strong> ${data.othername ?? 'N/A'}</p>
            <p class="mb-1"><strong>Admission No:</strong> ${data.admission_number ?? 'N/A'}</p>
            <p class="mb-1"><strong>Arm:</strong> ${data.arm ?? 'N/A'}</p>
            <p class="mb-1"><strong>Category:</strong> ${data.category ?? 'N/A'}</p>
        </div>
    </div>
`;

                });
 /*$.get('/user/details/' + userId, function(data) {
             tooltipContent.innerHTML = `
                <p><strong>Surname:</strong> ${data.surname ?? 'N/A'}</p>
                <p><strong>Firstname:</strong> ${data.firstname ?? 'N/A'}</p>
                <p><strong>Othername:</strong> ${data.othername ?? 'N/A'}</p>
                 <p><strong>Admission NO:</strong> ${data.admission_number ?? 'N/A'}</p>
                <p><strong>Arm:</strong> ${data.arm ?? 'N/A'}</p>
                <p><strong>Category:</strong> ${data.category ?? 'N/A'}</p>
            `;*/
//              $.get('/user/details/' + userId, function(data) {
//             let content = `
//                 <p><strong>Surname:</strong> ${data.surname ?? 'N/A'}</p>
//                 <p><strong>Firstname:</strong> ${data.firstname ?? 'N/A'}</p>
//                 <p><strong>Othername:</strong> ${data.othername ?? 'N/A'}</p>
//                  <p><strong>Admission NO:</strong> ${data.admission_number ?? 'N/A'}</p>
//                 <p><strong>Arm:</strong> ${data.arm ?? 'N/A'}</p>
//                 <p><strong>Category:</strong> ${data.category ?? 'N/A'}</p>
//             `;
//            // $('#userInfoContent').html(content);
// tooltipContent.innerHTML=content;
            // Position tooltip near the row  <strong>Last Login:</strong> $ {data.last_login ?? 'N/A'}
            const rect = this.getBoundingClientRect();
            tooltip.style.top = (rect.top + window.scrollY + 20) + "px";
            tooltip.style.left = (rect.left + window.scrollX + 150) + "px";
            tooltip.classList.remove("d-none");
        });

        row.addEventListener("mouseleave", function () {
            tooltip.classList.add("d-none");
        });
    });
});
</script>

@endsection