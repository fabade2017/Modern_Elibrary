<?php 
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class DataMapperController extends Controller
{
    public function index()
    {
        // List DB tables for dropdown
        $tables = DB::select('SHOW TABLES');
        $tables = array_map('current', $tables);

        return view('admin.data_mapper.index', compact('tables'));
    }

    public function fetchApi(Request $request)
    {
        $url = $request->input('api_url');
        $data = json_decode(file_get_contents($url), true);

        if (!$data || !is_array($data)) {
            return back()->withErrors('Invalid API response.');
        }

        $tableName = 'api_import_' . time();

        // Get first row for schema
        $firstRow = $data[0] ?? [];
        // Schema::create($tableName, function ($table) use ($firstRow) {
        //     $table->id();
        //     foreach ($firstRow as $key => $value) {
        //         $table->string($key)->nullable();
        //     }
        //     $table->timestamps();
        // });
                    // Schema::create($tableName, function ($table) use ($firstRow) {
                    //     // If JSON already has "id", don’t add another auto-increment id
                    //     if (!array_key_exists('id', $firstRow)) {
                    //         $table->id();
                    //     }

                    //     foreach ($firstRow as $key => $value) {
                    //         // Prevent duplicate "id"
                    //         if ($key === 'id' && array_key_exists('id', $firstRow)) {
                    //             $table->string('id')->nullable();
                    //             continue;
                    //         }

                    //         $table->string($key)->nullable();
                    //     }

                    //     $table->timestamps();
                    // });
Schema::create($tableName, function ($table) use ($firstRow) {
    // If your JSON already has "id" (UUID style), don’t create auto-increment
    if (!array_key_exists('id', $firstRow)) {
        $table->id();
    }

    foreach ($firstRow as $key => $value) {
        // Handle "id" specially (UUIDs)
        if ($key === 'id' && array_key_exists('id', $firstRow)) {
            $table->string('id', 50)->nullable(); // UUID fits in 36 chars
            continue;
        }

        // Decide column type
        if (is_numeric($value)) {
            $table->bigInteger($key)->nullable();
        } elseif (is_string($value)) {
            if (strlen($value) > 255) {
                $table->text($key)->nullable();
            } else {
                $table->string($key, 255)->nullable();
            }
        } else {
            $table->string($key, 255)->nullable();
        }
    }

    $table->timestamps();
});

        // Insert data
        foreach ($data as $row) {
            DB::table($tableName)->insert($row);
        }

        return back()->with('success', "Table '$tableName' created and data inserted.")
                     ->with('api_table', $tableName);
    }
public function saveMapping(Request $request)
{
    $apiTable = $request->input('api_table');
    $targetTable = $request->input('target_table');
    $mappings = $request->input('mappings', []); // default to empty array

    if (empty($mappings)) {
        return back()->with('error', 'No mappings provided.');
    }

    // fetch API table rows
    $apiData = DB::table($apiTable)->get();

    foreach ($apiData as $row) {
        $insert = [];

        foreach ($mappings as $apiCol => $targetCol) {
            if (isset($row->$apiCol)) {
                $insert[$targetCol] = $row->$apiCol;
            }
        }

        if (!empty($insert)) {
            DB::table($targetTable)->insert($insert);
        }
    }

    return back()->with('success', "Data mapped into '$targetTable'.");
}

                    //     public function saveMapping(Request $request)
                    // {
                    //     $apiTable    = $request->input('api_table');
                    //     $targetTable = $request->input('target_table');
                    //     $mappings    = $request->input('mappings', []); // default to []

                    //     if (empty($mappings)) {
                    //         return back()->with('error', 'No mappings were provided.');
                    //     }

                    //     $apiData = DB::table($apiTable)->get();

                    //     foreach ($apiData as $row) {
                    //         $insert = [];
                    //         foreach ($mappings as $apiCol => $targetCol) {
                    //             if (!empty($targetCol) && isset($row->$apiCol)) {
                    //                 $insert[$targetCol] = $row->$apiCol;
                    //             }
                    //         }
                    //         if (!empty($insert)) {
                    //             DB::table($targetTable)->insert($insert);
                    //         }
                    //     }

                    //     return back()->with('success', "Data mapped into '$targetTable'.");
                    // }

// public function saveMapping(Request $request)
// {
//     $apiTable    = $request->input('api_table');
//     $targetTable = $request->input('target_table');
//     $mappings    = $request->input('mappings', []); // default to []

//     if (empty($mappings)) {
//         return back()->with('error', 'No mappings were provided.');
//     }

//     $apiData = DB::table($apiTable)->get();

//     foreach ($apiData as $row) {
//         $insert = [];
//         foreach ($mappings as $apiCol => $targetCol) {
//             if (!empty($targetCol) && isset($row->$apiCol)) {
//                 $insert[$targetCol] = $row->$apiCol;
//             }
//         }
//         if (!empty($insert)) {
//             DB::table($targetTable)->insert($insert);
//         }
//     }

//     return back()->with('success', "Data mapped into '$targetTable'.");
// }
public function getColumns(Request $request)
{
    $table = $request->input('table');

    if (!$table) {
        return response()->json(['columns' => []]);
    }

    try {
        $columns = \Schema::getColumnListing($table);
        return response()->json(['columns' => $columns]);
    } catch (\Exception $e) {
        return response()->json(['error' => $e->getMessage()], 500);
    }
}

    public function saveMappingGGGGG(Request $request)
    {
        $apiTable = $request->input('api_table');
        $targetTable = $request->input('target_table');
        $mappings = $request->input('mapping'); // e.g. ['api_col' => 'target_col']

        $apiData = DB::table($apiTable)->get();

        foreach ($apiData as $row) {
            $insert = [];
            foreach ($mappings as $apiCol => $targetCol) {
                $insert[$targetCol] = $row->$apiCol;
            }
            DB::table($targetTable)->insert($insert);
        }

        return back()->with('success', "Data mapped into '$targetTable'.");
    }

    public function deleteData(Request $request)
    {
        $apiTable = $request->input('api_table');
        $targetTable = $request->input('target_table');

        if (Schema::hasTable($apiTable)) {
            DB::table($apiTable)->truncate();
        }

        if (Schema::hasTable($targetTable)) {
            DB::table($targetTable)->truncate();
        }

        return back()->with('success', "Data cleared in both '$apiTable' and '$targetTable'.");
    }
}
