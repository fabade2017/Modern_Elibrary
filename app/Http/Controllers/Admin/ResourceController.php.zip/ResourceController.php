<?php
namespace App\Http\Controllers\Admin;

// use App\Http\Controllers\Controller;
// use App\Models\Resource;

// use App\Models\ResourceAccess;

// use App\Models\Group;
// use App\Models\User;
// use App\Models\Category;

// use App\Models\Role;

use App\Models\Classes;
use App\Models\ResourceType;
use App\Http\Controllers\Controller;
use App\Models\Resource;
use App\Models\ResourceAccess;
use App\Models\User;
use App\Models\Role;

use App\Models\Group;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;

class ResourceController extends Controller
{
    public function index()
    {
        $resources = Resource::latest()->paginate(10);
        return view('admin.resources.index', compact('resources'));
    }

    public function create()
    {
        $roles = Role::all();
        $classes = Classes::all();
        $groups = Group::all();
          $users = User::all();
           $resources = Resource::all();
           $resourceAccesses = ResourceAccess::all();
        $categories = Category::all();
         $resourceType = ResourceType::all();
        return view('admin.resources.create', compact('users','resources','resourceAccesses','roles','classes','groups','categories','resourceType'));
    }
public function store(Request $request)
    {
        // Log all request data
        Log::debug('Resource Store Request:', $request->all());

        // Validate the request
        $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
            'resource_type_id' => 'required|exists:resource_types,id',
            'category_id' => 'required|exists:categories,id',
            'file' => 'nullable|file|mimes:jpg,jpeg,png,gif,pdf,mp4|max:10240', // 10MB max
            'is_downloadable' => 'boolean',
            'is_viewable' => 'boolean',
            'active' => 'boolean',
        ]);

        $filePath = null;
        if ($request->hasFile('file')) {
            Log::debug('File detected in request:', [
                'name' => $request->file('file')->getClientOriginalName(),
                'size' => $request->file('file')->getSize(),
                'mime' => $request->file('file')->getMimeType(),
                'temp_path' => $request->file('file')->getPathname(),
            ]);

            if ($request->file('file')->isValid()) {
                try {
                    // Verify storage directory exists and is writable
                    $storagePath = storage_path('app/public/resources');
                    if (!file_exists($storagePath)) {
                        mkdir($storagePath, 0775, true);
                        Log::debug('Created storage directory:', ['path' => $storagePath]);
                    }
                    if (!is_writable($storagePath)) {
                        Log::error('Storage directory not writable:', ['path' => $storagePath]);
                        throw new \Exception('Storage directory is not writable: ' . $storagePath);
                    }

                    $filePath = $request->file('file')->store('resources', 'public');
                    Log::debug('File stored at:', ['path' => $filePath]);
                } catch (\Exception $e) {
                    Log::error('Failed to store file:', [
                        'error' => $e->getMessage(),
                        'file' => $request->file('file')->getClientOriginalName(),
                        'trace' => $e->getTraceAsString(),
                    ]);
                    return redirect()->back()->withErrors(['file' => 'Failed to store file: ' . $e->getMessage()])->withInput();
                }
            } else {
                Log::error('Invalid file uploaded:', [
                    'error' => $request->file('file')->getErrorMessage(),
                    'file' => $request->file('file')->getClientOriginalName(),
                ]);
                return redirect()->back()->withErrors(['file' => 'Invalid file uploaded: ' . $request->file('file')->getErrorMessage()])->withInput();
            }
        } else {
            Log::debug('No file detected in request.');
        }

        Resource::create([
            'title' => $request->title,
            'description' => $request->description,
            'resource_type_id' => $request->resource_type_id,
            'category_id' => $request->category_id,
            'file_path' => $filePath,
            'downloadable' => $request->boolean('is_downloadable'),
            'view_online' => $request->boolean('is_viewable'),
            'active' => $request->boolean('active'),
        ]);

        return redirect()->route('admin.resources.index')->with('success', 'Resource created successfully.');
    }
public function storekkkkk(Request $request)
    {
        // Log the request data for debugging
        Log::debug('Resource Store Request:', $request->all());
        if ($request->hasFile('file')) {
            Log::debug('File detected in request:', [
                'name' => $request->file('file')->getClientOriginalName(),
                'size' => $request->file('file')->getSize(),
                'mime' => $request->file('file')->getMimeType(),
            ]);
        } else {
            Log::debug('No file detected in request.');
        }

        // Validate the request
        $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
            'resource_type_id' => 'required|exists:resource_types,id',
            'category_id' => 'required|exists:categories,id',
         //   'file' => 'nullable|file|mimes:jpg,jpeg,png,gif,pdf,mp4|max:10240', // 10MB max
            'is_downloadable' => 'boolean',
            'is_viewable' => 'boolean',
            'active' => 'boolean',
        ]);

        $filePath = null;
        if ($request->hasFile('file') && $request->file('file')->isValid()) {
            $filePath = $request->file('file')->store('resources', 'public');
            Log::debug('File stored at:', ['path' => $filePath]);
        }

        Resource::create([
            'title' => $request->title,
            'description' => $request->description,
            'resource_type_id' => $request->resource_type_id,
            'category_id' => $request->category_id,
            //'file_path' => $filePath,
            'downloadable' => $request->boolean('is_downloadable'),
            'view_online' => $request->boolean('is_viewable'),
            'active' => $request->boolean('active'),
        ]);

        return redirect()->route('admin.resources.index')->with('success', 'Resource created successfully.');
    }
    public function storevvvvv(Request $request)
    {
        $request->validate([
           'title' => 'required|string|max:255',
        'description' => 'nullable|string',
      //  'resource_type' => 'required|string|in:video,audio,pdf,book',
        'file' => 'nullable|file',
        'url' => 'nullable|url',
        'is_viewable' => 'boolean',
        'is_downloadable' => 'boolean',
        'active' => 'boolean',
        'is_featured' => 'boolean',
        ]);

        $filePath = null;
        if ($request->hasFile('file')) {
            $filePath = $request->file('file')->store('resources', 'public');
        }
//ResourceType::create($request->all());
      Resource::create([
            'title' => $request->title,
            'description' => $request->description,
            'resource_type_id' => $request->resource_type,
            'category_id' => $request->category_id,
            'file_path' => $filePath,
          //  'url' => $request->url,
            'is_downloadable' => $request->boolean('is_downloadable'),
            'is_viewable' => $request->boolean('is_viewable'),
            'active' => $request->boolean('active'),
        ]);

        // // Attach access permissions
        // $resource->resourceAccesses()->create([
        //     'role_id' => $request->role_id,
        //     'class_id' => $request->class_id,
        //     'group_id' => $request->group_id,
        //     'active' => true
        // ]);

        return redirect()->route('admin.resources.index')->with('success', 'Resource created successfully.');
    }

    public function edit(Resource $resource)
    {
        $roles = Role::all();
        $classes = Classes::all();
        $groups = Group::all();
        return view('admin.resources.edit', compact('resource','roles','classes','groups'));
    }

    public function update(Request $request, Resource $resource)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'resource_type' => 'required|string',
            'file' => 'nullable|file|max:10240',
            'url' => 'nullable|url',
            'is_downloadable' => 'boolean',
            'is_viewable' => 'boolean',
            'active' => 'boolean',
        ]);

        $filePath = $resource->file_path;
        if ($request->hasFile('file')) {
            if ($filePath) Storage::disk('public')->delete($filePath);
            $filePath = $request->file('file')->store('resources', 'public');
        }

        $resource->update([
            'title' => $request->title,
            'description' => $request->description,
            'resource_type' => $request->resource_type,
            'file_path' => $filePath,
            'url' => $request->url,
            'is_downloadable' => $request->boolean('is_downloadable'),
            'is_viewable' => $request->boolean('is_viewable'),
            'active' => $request->boolean('active'),
        ]);

        return redirect()->route('admin.resources.index')->with('success', 'Resource updated successfully.');
    }

    public function destroy(Resource $resource)
    {
        if ($resource->file_path) {
            Storage::disk('public')->delete($resource->file_path);
        }
        $resource->delete();
        return redirect()->route('admin.resources.index')->with('success', 'Resource deleted successfully.');
    }
       public function toggleActive(Resource $group)
{
    $group->active = !$group->active;
    $group->save();
    return redirect()->back()->with('success', 'Group status updated.');
}
}
