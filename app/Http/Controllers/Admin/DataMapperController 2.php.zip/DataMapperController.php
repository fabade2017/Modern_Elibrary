<?php 
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class DataMapperController extends Controller
{
    public function index()
    {
        try {
            $tables = DB::select('SHOW TABLES');
            $tables = array_map('current', $tables); // Extract table names
            return view('admin.data_mapper', compact('tables'));
        } catch (\Exception $e) {
            Log::error('Error fetching tables', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);
            return view('admin.data_mapper.index', ['tables' => []])->with('error', 'Failed to load tables');
        }
    }

    public function fetchApi(Request $request)
    {
        $request->validate(['api_url' => 'required|url']);
        Log::info('Fetching API', ['url' => $request->api_url]);
        // Implement API fetching logic here
        return redirect()->route('data_mapper.index')->with('success', 'API fetched successfully');
    }

    public function saveMapping(Request $request)
    {
        $request->validate([
            'api_table' => 'required|string',
            'target_table' => 'required|string',
            'mappings' => 'required|array',
        ]);
        Log::info('Saving mapping', $request->all());
        // Implement saving logic
        return redirect()->route('data_mapper.index')->with('success', 'Mapping saved');
    }

    public function deleteData(Request $request)
    {
        $request->validate([
            'api_table' => 'required|string',
            'target_table' => 'required|string',
        ]);
        Log::info('Deleting data', $request->all());
        // Implement deletion logic
        return redirect()->route('data_mapper.index')->with('success', 'Data deleted');
    }

    public function getColumns(Request $request)
    {
        try {
            $apiTable = $request->query('api_table');
            $targetTable = $request->query('target_table');
            $singleTable = $request->query('table');

            if ($singleTable) {
                if (!DB::getSchemaBuilder()->hasTable($singleTable)) {
                    return response()->json(['error' => "Table '$singleTable' does not exist"], 404);
                }
                $columns = DB::getSchemaBuilder()->getColumnListing($singleTable);
                return response()->json($columns);
            }

            if (!$apiTable || !$targetTable) {
                return response()->json(['error' => 'Both API and target tables are required'], 400);
            }

            if (!DB::getSchemaBuilder()->hasTable($apiTable)) {
                return response()->json(['error' => "API table '$apiTable' does not exist"], 404);
            }
            if (!DB::getSchemaBuilder()->hasTable($targetTable)) {
                return response()->json(['error' => "Target table '$targetTable' does not exist"], 404);
            }

            $apiColumns = DB::getSchemaBuilder()->getColumnListing($apiTable);
            $targetColumns = DB::getSchemaBuilder()->getColumnListing($targetTable);

            return response()->json([
                'api_columns' => $apiColumns,
                'target_columns' => $targetColumns,
            ]);
        } catch (\Exception $e) {
            Log::error('Error fetching columns', [
                'api_table' => $apiTable,
                'target_table' => $targetTable,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);
            return response()->json(['error' => 'Failed to fetch columns: ' . $e->getMessage()], 500);
        }
    }
}