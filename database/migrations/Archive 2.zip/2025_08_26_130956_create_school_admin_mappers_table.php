<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('school_admin_mappers', function (Blueprint $table) {
            $table->id();
            $table->string('adminemail')->index(); // email of admin
            $table->string('school');              // school name or ID
            $table->unsignedInteger('studentcount')->default(0); // number of students
            $table->text('others')->nullable();    // extra info
            $table->boolean('active')->default(true); // status
            $table->timestamps(); // created_at, updated_at
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('school_admin_mappers');
    }
};
