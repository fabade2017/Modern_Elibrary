<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateStudentDataTable extends Migration
{
    public function up()
    {
        Schema::create('studentData', function (Blueprint $table) {
            $table->string('id')->primary();
            $table->string('name');
            $table->string('email')->unique()->nullable();
            $table->string('role');
            $table->string('institution_id')->nullable();
            $table->string('department_id')->nullable();
            $table->text('bio')->nullable();
            $table->string('username')->nullable();
            $table->string('phone')->nullable();
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('studentData');
    }
}